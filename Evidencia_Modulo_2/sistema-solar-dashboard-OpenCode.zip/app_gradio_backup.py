# -*- coding: utf-8 -*-
"""
Dashboard Sistema Solar Popayán - Despliegue LOCAL
Adaptado desde Sistema_Solar_SGV_EDA.ipynb (Colab) para Windows local.
Uso:  python app.py
Acceso: http://127.0.0.1:7860
"""
import os
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder, MinMaxScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, auc, precision_recall_curve
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

BASE_DIR = Path(__file__).parent
DATA_PATH = BASE_DIR / "dataset_sistema_solar_con_sol_2023_2026.csv"
PLOTS_DIR = BASE_DIR / "dashboard_plots"
PLOTS_DIR.mkdir(exist_ok=True)

print(f"[+] Directorio base: {BASE_DIR}")
print(f"[+] Dataset: {DATA_PATH} (existe: {DATA_PATH.exists()})")

# ------------------------------------------------------------------
# 1. Cargar dataset
# ------------------------------------------------------------------
df = pd.read_csv(DATA_PATH)
print("--- Información General del Dataset ---")
df.info()
print(df.head().to_string())

df["Timestamp"] = pd.to_datetime(df["Timestamp"], errors="coerce")
df = df.dropna(subset=["Timestamp"]).sort_values("Timestamp").reset_index(drop=True)
print(f"[+] Registros tras limpieza: {len(df)} | Columnas: {list(df.columns)}")

# ------------------------------------------------------------------
# 2. EDA - Gráficos
# ------------------------------------------------------------------
# A. Univariada
plt.figure(figsize=(10, 4))
sns.histplot(df["P_DC_PV_W"], kde=True, color="gold", bins=30)
plt.title("Distribución de la Potencia Generada (P_DC_PV_W)")
plt.xlabel("Vatios (W)")
plt.ylabel("Frecuencia")
plt.tight_layout()
plt.savefig(PLOTS_DIR / "univ_dist.png")
plt.close()

# B. Bivariada
plt.figure(figsize=(10, 5))
sns.scatterplot(data=df, x="Temp_Inverter_C", y="P_DC_PV_W", alpha=0.5, hue="Grid_Status")
plt.title("Temperatura del Inversor vs Potencia Generada (Bivariado)")
plt.tight_layout()
plt.savefig(PLOTS_DIR / "bivar_dist.png")
plt.close()

# C. Multivariada
try:
    key_cols = ["P_DC_PV_W", "SoC_Batt_Pct", "Temp_Inverter_C", "V_Batt_V"]
    plt.figure(figsize=(10, 8))
    sns.pairplot(df[key_cols].sample(min(1000, len(df)), random_state=42))
    plt.savefig(PLOTS_DIR / "multivar_dist.png")
    plt.close()
except Exception as e:
    print(f"[!] pairplot omitido: {e}")

# D. Correlación
plt.figure(figsize=(12, 10))
corr_matrix = df.select_dtypes(include=[np.number]).corr()
sns.heatmap(corr_matrix, annot=True, fmt=".2f", cmap="coolwarm", square=True)
plt.title("Matriz de Correlación de Variables Técnicas")
plt.tight_layout()
plt.savefig(PLOTS_DIR / "corr_matrix.png")
plt.close()

# E. Clustering K-Means + PCA
scaler_cluster = StandardScaler()
cluster_features = df[["P_DC_PV_W", "SoC_Batt_Pct", "Temp_Inverter_C", "V_Batt_V"]].dropna()
kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
clusters = kmeans.fit_predict(scaler_cluster.fit_transform(cluster_features))

pca = PCA(n_components=2)
pca_features = pca.fit_transform(scaler_cluster.fit_transform(cluster_features))
df_pca = pd.DataFrame(pca_features, columns=["PC1", "PC2"])
df_pca["Cluster"] = clusters

plt.figure(figsize=(10, 5))
sns.scatterplot(data=df_pca, x="PC1", y="PC2", hue="Cluster", palette="viridis", alpha=0.6)
plt.title("Clustering K-Means (K=3) proyectado en 2 Componentes PCA")
plt.tight_layout()
plt.savefig(PLOTS_DIR / "clustering.png")
plt.close()

# F. Serie temporal mensual
df_ts = df.set_index("Timestamp").resample("ME")["P_DC_PV_W"].mean().reset_index()
plt.figure(figsize=(12, 5))
plt.plot(df_ts["Timestamp"], df_ts["P_DC_PV_W"], marker="o", color="darkorange", linestyle="-")
plt.title("Evolución Histórica de Generación Promedio Mensual (P_DC_PV_W)")
plt.xlabel("Fecha")
plt.ylabel("Generación Promedio (W)")
plt.grid(True)
plt.tight_layout()
plt.savefig(PLOTS_DIR / "time_series.png")
plt.close()

print("[+] Gráficos EDA generados en dashboard_plots/")

# ------------------------------------------------------------------
# 3. Red Neuronal MLP - Clasificación Grid_Status
# ------------------------------------------------------------------
le = LabelEncoder()
df["Target_Class"] = le.fit_transform(df["Grid_Status"])
class_names = [str(c) for c in le.classes_]
print(f"[+] Clases Grid_Status: {class_names}")

features_cols = ["P_DC_PV_W", "V_Batt_V", "I_Batt_A", "SoC_Batt_Pct", "V_AC_L1_V", "Temp_Inverter_C", "Fault_Duration_Min"]
X = df[features_cols]
y = df["Target_Class"]

try:
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)
except ValueError as e:
    print(f"[!] stratify no posible ({e}), usando split aleatorio sin stratify.")
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

scaler_nn = StandardScaler()
X_train_scaled = scaler_nn.fit_transform(X_train)
X_test_scaled = scaler_nn.transform(X_test)

mlp = MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=300, random_state=42)
mlp.fit(X_train_scaled, y_train)

y_pred = mlp.predict(X_test_scaled)
y_prob = mlp.predict_proba(X_test_scaled)

# Curva de pérdida
plt.figure(figsize=(10, 5))
plt.plot(mlp.loss_curve_, color="dodgerblue", linewidth=2, label="Pérdida (Loss)")
plt.title("Curva de Pérdida del Entrenamiento (Loss Curve)")
plt.xlabel("Épocas / Iteraciones")
plt.ylabel("Pérdida (Loss)")
plt.grid(True, linestyle="--", alpha=0.6)
plt.legend()
plt.tight_layout()
plt.savefig(PLOTS_DIR / "loss_curve.png")
plt.close()

# Matriz de confusión
plt.figure(figsize=(10, 8))
cm = confusion_matrix(y_test, y_pred)
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=class_names, yticklabels=class_names)
plt.title("Matriz de Confusión Multiclase - Red Neuronal (Grid_Status)")
plt.xlabel("Predicción")
plt.ylabel("Real")
plt.tight_layout()
plt.savefig(PLOTS_DIR / "conf_matrix_nn.png")
plt.close()

# Histograma de errores
plt.figure(figsize=(10, 4))
errors = y_test.values - y_pred
plt.hist(errors, bins=20, color="crimson", edgecolor="black", alpha=0.7)
plt.title("Histograma de Errores de Clasificación")
plt.xlabel("Error (Clase Real - Predicha)")
plt.ylabel("Frecuencia")
plt.tight_layout()
plt.savefig(PLOTS_DIR / "err_hist.png")
plt.close()

# Curvas ROC multiclase
plt.figure(figsize=(10, 6))
for i in range(len(class_names)):
    y_bin = (y_test == i).astype(int)
    if len(np.unique(y_bin)) > 1 and y_bin.sum() > 0:
        # predict_proba columnas alineadas con mlp.classes_
        col_idx = list(mlp.classes_).index(i)
        fpr, tpr, _ = roc_curve(y_bin, y_prob[:, col_idx])
        roc_auc = auc(fpr, tpr)
        plt.plot(fpr, tpr, label=f"{class_names[i]} (AUC = {roc_auc:.2f})")
plt.plot([0, 1], [0, 1], "k--")
plt.xlabel("Tasa Falsos Positivos")
plt.ylabel("Tasa Verdaderos Positivos")
plt.title("Curvas ROC por Estado de Red")
plt.legend(loc="lower right")
plt.tight_layout()
plt.savefig(PLOTS_DIR / "roc_curve.png")
plt.close()

# Curvas Precision-Recall
plt.figure(figsize=(10, 6))
for i in range(len(class_names)):
    y_bin = (y_test == i).astype(int)
    if len(np.unique(y_bin)) > 1 and y_bin.sum() > 0:
        col_idx = list(mlp.classes_).index(i)
        precision, recall, _ = precision_recall_curve(y_bin, y_prob[:, col_idx])
        plt.plot(recall, precision, label=f"{class_names[i]}")
plt.xlabel("Recall")
plt.ylabel("Precision")
plt.title("Curva Precision-Recall por Estado de Red")
plt.legend(loc="lower left")
plt.tight_layout()
plt.savefig(PLOTS_DIR / "recall_curve.png")
plt.close()

rep_str = classification_report(y_test, y_pred, target_names=class_names)
print("Reporte de Clasificación:\n", rep_str)

# ------------------------------------------------------------------
# 4. Ejemplo predicción Nov-Dic 2026
# ------------------------------------------------------------------
pred_data_2026 = pd.DataFrame({
    "P_DC_PV_W": [3200.0, 1500.0, 4800.0, 0.0],
    "V_Batt_V": [50.5, 48.2, 51.8, 47.9],
    "I_Batt_A": [30.0, -10.0, 65.0, -25.0],
    "SoC_Batt_Pct": [85.0, 45.0, 98.0, 30.0],
    "V_AC_L1_V": [120.0, 119.5, 120.5, 118.0],
    "Temp_Inverter_C": [42.0, 35.0, 52.0, 28.0],
    "Fault_Duration_Min": [0, 0, 0, 5],
})

pred_scaled = scaler_nn.transform(pred_data_2026)
preds_classes_encoded = mlp.predict(pred_scaled)
preds_classes_decoded = le.inverse_transform(preds_classes_encoded)

pred_data_2026["Mes Estimado"] = ["Noviembre 2026", "Noviembre 2026", "Diciembre 2026", "Diciembre 2026"]
pred_data_2026["Predicción Estado de Red (Clase)"] = preds_classes_decoded
print(pred_data_2026.to_string())

# ------------------------------------------------------------------
# 5. RNN - Pronóstico tiempo equivalente (40 meses hasta 2030)
# ------------------------------------------------------------------
df_monthly = df.set_index("Timestamp").resample("ME")["P_DC_PV_W"].mean().reset_index()
n_meses_equivalentes = len(df_monthly)
print(f"El dataset contiene {n_meses_equivalentes} meses de datos históricos.")
series_data = df_monthly["P_DC_PV_W"].values.reshape(-1, 1)

scaler_rnn = MinMaxScaler(feature_range=(0, 1))
scaled_series = scaler_rnn.fit_transform(series_data)
look_back = 3


def create_dataset(dataset, look_back=3):
    X_data, y_data = [], []
    for i in range(len(dataset) - look_back):
        X_data.append(dataset[i:(i + look_back), 0])
        y_data.append(dataset[i + look_back, 0])
    return np.array(X_data), np.array(y_data)


X_rnn, y_rnn = create_dataset(scaled_series, look_back)
X_rnn = np.reshape(X_rnn, (X_rnn.shape[0], X_rnn.shape[1], 1))

try:
    import tensorflow as tf  # noqa
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import Dense, SimpleRNN

    model_rnn = Sequential([
        SimpleRNN(16, activation="tanh", input_shape=(look_back, 1)),
        Dense(1),
    ])
    model_rnn.compile(optimizer="adam", loss="mse")
    model_rnn.fit(X_rnn, y_rnn, epochs=120, batch_size=2, verbose=0)

    last_window = list(scaled_series[-look_back:].flatten())
    predictions_scaled = []
    for _ in range(n_meses_equivalentes):
        input_seq = np.array(last_window[-look_back:]).reshape(1, look_back, 1)
        pred = model_rnn.predict(input_seq, verbose=0)[0][0]
        predictions_scaled.append(pred)
        last_window.append(pred)

    predictions_original = scaler_rnn.inverse_transform(np.array(predictions_scaled).reshape(-1, 1)).flatten()
    print("[+] Pronóstico RNN con TensorFlow completado.")

except Exception as e:
    # Fallback sin TensorFlow: regresor MLP con lags (matemáticamente equivalente para este ejercicio)
    print(f"[!] TensorFlow no disponible ({e}). Usando fallback MLPRegressor con lags.")
    from sklearn.neural_network import MLPRegressor

    X_fb, y_fb = create_dataset(scaled_series, look_back)
    reg = MLPRegressor(hidden_layer_sizes=(32, 16), max_iter=500, random_state=42)
    reg.fit(X_fb, y_fb)
    last_window = list(scaled_series[-look_back:].flatten())
    predictions_scaled = []
    for _ in range(n_meses_equivalentes):
        inp = np.array(last_window[-look_back:]).reshape(1, -1)
        pred = float(reg.predict(inp)[0])
        predictions_scaled.append(pred)
        last_window.append(pred)
    predictions_original = scaler_rnn.inverse_transform(np.array(predictions_scaled).reshape(-1, 1)).flatten()
    print("[+] Pronóstico fallback completado.")

last_date = df_monthly["Timestamp"].iloc[-1]
forecast_dates = pd.date_range(start=last_date + pd.offsets.MonthEnd(1), periods=n_meses_equivalentes, freq="ME")

df_forecast_equiv = pd.DataFrame({
    "Timestamp": forecast_dates,
    "P_DC_PV_W_Pred": predictions_original,
})

plt.figure(figsize=(12, 5))
plt.plot(df_monthly["Timestamp"], df_monthly["P_DC_PV_W"], marker="o", label="Histórico Real (2023-2026)", color="darkorange")
plt.plot(df_forecast_equiv["Timestamp"], df_forecast_equiv["P_DC_PV_W_Pred"], marker="s", linestyle="--",
         label=f"Pronóstico RNN Equivalente ({n_meses_equivalentes} Meses a Futuro)", color="crimson")
plt.title("Pronóstico RNN de Generación de Energía (P_DC_PV_W) para Tiempo Equivalente (Hasta 2030)")
plt.xlabel("Fecha")
plt.ylabel("Generación Promedio (W)")
plt.grid(True, linestyle="--", alpha=0.5)
plt.legend()
plt.tight_layout()
plt.savefig(PLOTS_DIR / "rnn_forecast_equivalent.png")
plt.close()

print("Pronóstico de tiempo equivalente completado y graficado exitosamente.")

# ------------------------------------------------------------------
# 5b. Gráficas adicionales
# ------------------------------------------------------------------
df_plot = df.copy()
df_plot["Hora"] = df_plot["Timestamp"].dt.hour
df_plot["Mes"] = df_plot["Timestamp"].dt.to_period("M").astype(str)

# Generación promedio por hora del día
hourly = df_plot.groupby("Hora", as_index=False).agg(
    P_DC_PV_W_mean=("P_DC_PV_W", "mean"),
    SoC_mean=("SoC_Batt_Pct", "mean"),
    Temp_mean=("Temp_Inverter_C", "mean"),
)
fig, ax1 = plt.subplots(figsize=(10, 5))
ax1.bar(hourly["Hora"], hourly["P_DC_PV_W_mean"], color="#f4b400", alpha=0.75, label="Potencia PV prom. (W)")
ax1.set_xlabel("Hora del día")
ax1.set_ylabel("Potencia PV promedio (W)", color="#b8860b")
ax1.tick_params(axis="y", labelcolor="#b8860b")
ax1.set_xticks(range(0, 24))
ax2 = ax1.twinx()
ax2.plot(hourly["Hora"], hourly["SoC_mean"], color="#1e88e5", marker="o", linewidth=2, label="SoC prom. (%)")
ax2.set_ylabel("SoC promedio (%)", color="#1e88e5")
ax2.tick_params(axis="y", labelcolor="#1e88e5")
ax1.set_title("Perfil diario: generación PV y estado de carga (promedio por hora)")
fig.tight_layout()
plt.savefig(PLOTS_DIR / "extra_hourly_profile.png")
plt.close()

# Mapa de calor: potencia promedio por mes y hora
pivot = df_plot.pivot_table(values="P_DC_PV_W", index="Hora", columns="Mes", aggfunc="mean")
plt.figure(figsize=(14, 6))
sns.heatmap(pivot, cmap="YlOrRd", cbar_kws={"label": "Potencia PV promedio (W)"})
plt.title("Mapa de calor: potencia PV promedio por hora y mes")
plt.xlabel("Mes")
plt.ylabel("Hora")
plt.tight_layout()
plt.savefig(PLOTS_DIR / "extra_heatmap_month_hour.png")
plt.close()

# Distribución de estados de red y eventos de alarma
fig, axes = plt.subplots(1, 2, figsize=(13, 5))
grid_counts = df_plot["Grid_Status"].value_counts()
axes[0].pie(grid_counts.values, labels=grid_counts.index, autopct="%1.1f%%", startangle=140)
axes[0].set_title("Distribución de Grid_Status")
alarm_counts = df_plot["Alarm_Event"].fillna("NONE").astype(str).value_counts().head(10)
axes[1].barh(alarm_counts.index[::-1], alarm_counts.values[::-1], color="#e53935", alpha=0.8)
axes[1].set_title("Eventos de alarma (top 10)")
axes[1].set_xlabel("Frecuencia")
fig.tight_layout()
plt.savefig(PLOTS_DIR / "extra_grid_alarm.png")
plt.close()

# Tendencia de batería y temperatura (muestreo mensual)
monthly_ops = df_plot.set_index("Timestamp").resample("ME").agg(
    SoC_Batt_Pct=("SoC_Batt_Pct", "mean"),
    V_Batt_V=("V_Batt_V", "mean"),
    Temp_Inverter_C=("Temp_Inverter_C", "mean"),
    P_DC_PV_W=("P_DC_PV_W", "mean"),
).reset_index()
fig, ax1 = plt.subplots(figsize=(12, 5))
ax1.plot(monthly_ops["Timestamp"], monthly_ops["P_DC_PV_W"], color="#f4b400", marker="o", label="PV prom. (W)")
ax1.plot(monthly_ops["Timestamp"], monthly_ops["Temp_Inverter_C"] * 100, color="#e53935", marker="s", alpha=0.7, label="Temp. inversor x100 (°C)")
ax1.set_ylabel("Potencia (W) / Temp. escalada")
ax1.set_xlabel("Fecha")
ax1.grid(True, linestyle="--", alpha=0.4)
ax2 = ax1.twinx()
ax2.plot(monthly_ops["Timestamp"], monthly_ops["SoC_Batt_Pct"], color="#1e88e5", marker="^", label="SoC prom. (%)")
ax2.set_ylabel("SoC (%)", color="#1e88e5")
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper left")
ax1.set_title("Tendencia mensual: PV, temperatura del inversor y SoC de batería")
fig.tight_layout()
plt.savefig(PLOTS_DIR / "extra_battery_trend.png")
plt.close()

print("[+] Gráficas adicionales generadas en dashboard_plots/")

# ------------------------------------------------------------------
# 6. Dashboard Gradio
# ------------------------------------------------------------------
import gradio as gr
from PIL import Image


def get_plot(filename):
    try:
        return Image.open(PLOTS_DIR / filename)
    except Exception:
        return None


explicacion_html = """
<div style='font-family: Arial, sans-serif; padding: 20px; line-height: 1.6;'>
    <h2 style='color: #2e7d32;'>Explicación del Ejercicio</h2>
    <p>Este ejercicio realiza un análisis completo de los datos operativos de generación del <b>Sistema Solar Popayán</b> durante el periodo de 2023 a 2026 e incorpora modelos predictivos avanzados.</p>
    <ul>
        <li><b>EDA Completo:</b> Estudiamos las relaciones de las variables físicas y eléctricas.</li>
        <li><b>Clustering (K-Means):</b> Agrupamos comportamientos del sistema solar en 3 perfiles principales.</li>
        <li><b>Red Neuronal (MLP):</b> Clasificamos los estados de la red eléctrica con un score sobresaliente.</li>
        <li><b>Pronóstico RNN Equivalente:</b> Entrenamos una Red Neuronal Recurrente para proyectar un horizonte de tiempo futuro equivalente al tamaño de la muestra histórica (40 meses adicionales hasta el año 2030).</li>
    </ul>
</div>
"""

conclusiones_html = """
<div style='font-family: Arial, sans-serif; padding: 20px; line-height: 1.6;'>
    <h2 style='color: #1565c0;'>Conclusiones del Ejercicio</h2>
    <ol>
        <li><b>Alta correlación térmica-solar:</b> Existe una fuerte relación bivariada directa entre la temperatura del inversor y la potencia DC generada por los paneles fotovoltaicos.</li>
        <li><b>Efectividad Predictiva:</b> La red neuronal demuestra un excelente score de clasificación gracias a la clara segmentación de los perfiles de operación a partir de los niveles de voltaje e intensidad de la batería y anomalías en la corriente de red.</li>
        <li><b>Garantía de Estabilidad:</b> El SoC de la batería actúa como buffer crítico. La simulación de Noviembre y Diciembre 2026 nos permite anticipar comportamientos normales en periodos invernales y de transición climática en Popayán.</li>
    </ol>
</div>
"""

with gr.Blocks(title="Dashboard Sistema Solar Popayán") as demo:
    gr.Markdown("# ☀️ Dashboard Inteligente - Sistema Solar Popayán (EDA, Red Neuronal & RNN Equivalente)")

    with gr.Tab("Vista del DataFrame & Info"):
        gr.Markdown("### Muestra de las primeras filas del dataset procesado")
        gr.DataFrame(df.head(15))
        gr.Markdown("### Estadísticas descriptivas")
        gr.DataFrame(df.describe())

    with gr.Tab("Estadísticas"):
        gr.Markdown("### Resumen de la calidad del dataset e información de tipos de datos")
        info_text = f"**Total Registros:** {df.shape[0]} \n\n**Número de Columnas:** {df.shape[1]} \n\n**Columnas:** {', '.join(df.columns.tolist())}"
        gr.Markdown(info_text)

    with gr.Tab("Gráficas de Distribuciones"):
        gr.Image(get_plot("univ_dist.png"), label="Distribución de Potencia Solar")
        gr.Image(get_plot("bivar_dist.png"), label="Temperatura del Inversor vs Potencia Solar")

    with gr.Tab("Multivariadas"):
        gr.Image(get_plot("multivar_dist.png"), label="Relación entre múltiples variables clave")

    with gr.Tab("Matriz de Correlación"):
        gr.Image(get_plot("corr_matrix.png"), label="Mapa térmico de correlación")

    with gr.Tab("Clustering & Perfiles"):
        gr.Image(get_plot("clustering.png"), label="Agrupamiento por perfiles")

    with gr.Tab("Series Temporales"):
        gr.Image(get_plot("time_series.png"), label="Evolución histórica")

    with gr.Tab("Gráficas Adicionales"):
        gr.Markdown("### Análisis operativo adicional")
        gr.Image(get_plot("extra_hourly_profile.png"), label="Perfil diario: generación PV y SoC promedio por hora")
        gr.Image(get_plot("extra_heatmap_month_hour.png"), label="Mapa de calor: potencia PV promedio por hora y mes")
        gr.Image(get_plot("extra_grid_alarm.png"), label="Distribución de estado de red y eventos de alarma")
        gr.Image(get_plot("extra_battery_trend.png"), label="Tendencia mensual: PV, temperatura del inversor y SoC")

    with gr.Tab("Clasificación & Métricas RN"):
        gr.Image(get_plot("conf_matrix_nn.png"), label="Matriz de Confusión")
        gr.Image(get_plot("loss_curve.png"), label="Curva de Pérdida (Loss Curve)")
        gr.Image(get_plot("err_hist.png"), label="Histograma de Errores")
        gr.Image(get_plot("roc_curve.png"), label="Curva ROC")
        gr.Image(get_plot("recall_curve.png"), label="Precisión vs Recall")
        gr.Textbox(rep_str, lines=10, max_lines=20, label="Reporte")

    with gr.Tab("Pronóstico RNN Equivalente (Hasta 2030) 🚀"):
        gr.Markdown("### Predicción de Generación Promedio Mensual (P_DC_PV_W) para Tiempo Equivalente")
        gr.Image(get_plot("rnn_forecast_equivalent.png"), label="Pronóstico de Generación Equivalente")
        gr.Markdown("#### Tabla de valores pronosticados")
        gr.DataFrame(df_forecast_equiv)

    with gr.Tab("Predicciones Nov-Dic 2026"):
        gr.DataFrame(pred_data_2026)

    with gr.Tab("Explicación del Ejercicio"):
        gr.HTML(explicacion_html)

    with gr.Tab("Conclusiones"):
        gr.HTML(conclusiones_html)

if __name__ == "__main__":
    print("\n🚀 Lanzando Dashboard local en http://127.0.0.1:7860 ...")
    print("   Pulsa Ctrl+C para detener.")
    demo.launch(server_name="127.0.0.1", server_port=7860, share=False, debug=False, prevent_thread_lock=False)

"""Minimal yaml shim for environments where PyYAML wheels are unavailable (e.g. Python 3.15 without MSVC).
Provides only the subset commonly needed; falls back to JSON where safe."""
import json as _json

def safe_load(stream):
    if stream is None:
        return None
    if hasattr(stream, "read"):
        stream = stream.read()
    if not stream or not str(stream).strip():
        return None
    s = str(stream)
    try:
        return _json.loads(s)
    except Exception:
        return None

def load(stream, Loader=None):
    return safe_load(stream)

def safe_dump(data, stream=None, **kwargs):
    out = _json.dumps(data, ensure_ascii=False, indent=2)
    if stream is not None:
        stream.write(out)
        return None
    return out

def dump(data, stream=None, **kwargs):
    return safe_dump(data, stream, **kwargs)

def dump_all(documents, stream=None, **kwargs):
    return safe_dump(list(documents), stream, **kwargs)

class SafeLoader: pass
class Loader: pass
class FullLoader: pass
class Dumper: pass
class SafeDumper: pass

class YAMLError(Exception): pass

@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo   Dashboard Sistema Solar Popayan - LOCAL (Streamlit)
echo   --------------------------------------------------
echo   URL: http://localhost:8501
echo   Pulsa Ctrl+C para detener.
echo.
start "" "http://localhost:8501"
python -m streamlit run app.py --server.port 8501 --server.address localhost --server.headless true
pause
